import loadNavBar from './modules/navBar';

loadNavBar();
