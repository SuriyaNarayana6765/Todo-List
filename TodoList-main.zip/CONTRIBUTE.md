### How to configure TodoList in your setup ###

1. "git clone" the repository
2. Run "npm install" in root folder.
3. Run "npm run watch" in same place.
4. Open "dist/index.html" via Live server.
5. Any changes made in code will be applied in live server.
