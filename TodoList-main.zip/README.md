# TodoList

![image](https://user-images.githubusercontent.com/89571066/195509743-90d4b328-0ef7-4cdd-bb88-967fafbd8c44.png)


Want to contribute ? Please take a look at <a href="https://github.com/debanjana-a11y/TodoList/blob/main/CONTRIBUTE.md" target="_blank">Configuration Steps</a>
  
 
